# tradeo-extension
Funktionserweiterung von Plenty, Webshop, Ticket-System und mehr.

Changelog v3.0.1.5:
- Verbessertes Suchfilterverhalten in allen Suchtabs (erklärt im Video)
- Neue Hotkeys für schnellere Auftragssuche (erklärt im Video)
- Diverse Code-Optimierungen

Installation in Google Chrome:
1. neueste "tradeoExtension" ZIP herunterladen
2. ZIP entpacken
3. oben rechts in Menüleiste auf das Puzzleteil-Symbol klicken
4. Ganz unten Zahnrad "Erweiterungen verwalten" klicken
5. "Entpackte Erweiterung laden"
6. Entpackten Ordner auswählen
7. Ggf. alle Seiten refreshen oder Browser neustarten

Installation in Firefox:
1. neueste "tradeoExtension" XPI herunterladen
2. Doppelklick und mit Firefox öffnen
3. Hinzufügen bestätigen
4. Ggf. alle Seiten refreshen oder Browser neustarten
